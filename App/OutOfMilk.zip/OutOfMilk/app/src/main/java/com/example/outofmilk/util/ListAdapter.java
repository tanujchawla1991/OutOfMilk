package com.example.outofmilk.util;

import java.util.ArrayList;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.outofmilk.R;
import com.example.outofmilk.model.CartDataModel;

public class ListAdapter extends BaseAdapter {
	 ArrayList<CartDataModel> listArray;
	 DBAdapter db;
	 
	    public ListAdapter(ArrayList<CartDataModel> listArray) {
	        this.listArray = listArray;
	    }
	 
	    @Override
	    public int getCount() {
	        return listArray.size();    // total number of elements in the list
	    }
	 
	    @Override
	    public Object getItem(int i) {
	        return listArray.get(i);    // single item in the list
	    }
	 
	    @Override
	    public long getItemId(int i) {
	        return i;                   // index number
	    }
	 
	    @Override
	    public View getView(final int index, View view, final ViewGroup parent) {
	 
	        if (view == null) {
	            LayoutInflater inflater = LayoutInflater.from(parent.getContext());
	            view = inflater.inflate(R.layout.cart_item, parent, false);
	        }
	        
	        final CartDataModel dataModel = listArray.get(index);

	        TextView textView1 = (TextView) view.findViewById(R.id.textView1);
	        textView1.setText(dataModel.getQuantity()+" "+dataModel.getItemName());

	        TextView textView2 = (TextView) view.findViewById(R.id.textView2);
	        textView2.setText("Consume By: "+dataModel.getDate());

			ImageButton b1 = (ImageButton) view.findViewById(R.id.imageButton1);
			b1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					String item_name = dataModel.getItemName();
					int item_quantity = dataModel.getQuantity();
					db.open();
					db.deleteItem(dataModel.getId());
					Toast.makeText(v.getContext(), item_quantity + " - " + item_name + " have been deleted from the cart.", Toast.LENGTH_LONG).show();
					db.close();
					listArray.remove(index);
					notifyDataSetChanged();
				}
			});
	        
	        ImageView imageView2 = (ImageView) view.findViewById(R.id.imageView2);
	        if(dataModel.getItemName().equalsIgnoreCase("Skim Milk"))
	        {
	        	imageView2.setImageResource(R.drawable.skim);
	        }
	        else if(dataModel.getItemName().equalsIgnoreCase("One Percent Milk"))
	        {
	        	imageView2.setImageResource(R.drawable.onepercent);
	        }
	        else if(dataModel.getItemName().equalsIgnoreCase("Two Percent Milk"))
	        {
	        	imageView2.setImageResource(R.drawable.twopercent);
	        }
	        else if(dataModel.getItemName().equalsIgnoreCase("Chocolate Milk"))
	        {
	        	imageView2.setImageResource(R.drawable.chocolate);
	        }
	        else if(dataModel.getItemName().equalsIgnoreCase("Regular Milk"))
	        {
	        	imageView2.setImageResource(R.drawable.regular);
	        }
	        
	        return view;
	    }
	    
	}