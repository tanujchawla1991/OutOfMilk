package com.example.outofmilk.model;

import java.io.Serializable;

public class Store implements Serializable, Comparable{
    int id;
    String name;
    String address;
    double latitude;
    double longitude;
    double distance;
    int loyalty_index;
    double weight_num;
    double weight_den;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public double getDistance() {
        return distance;
    }

    public void setDistance(double distance) {
        this.distance = distance;
    }

    public int getLoyalty_index() {
        return loyalty_index;
    }

    public void setLoyalty_index(int loyalty_index) {
        this.loyalty_index = loyalty_index;
    }

    public double getWeight_num() {
        return weight_num;
    }

    public void setWeight_num(double weight_num) {
        this.weight_num = weight_num;
    }

    public double getWeight_den() {
        return weight_den;
    }

    public void setWeight_den(double weight_den) {
        this.weight_den = weight_den;
    }

    @Override
    public int compareTo(Object obj) {
        Store another=(Store)obj;
        if(this.distance<another.distance)
        {
            return -1;
        }
        else if(this.distance>another.distance)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
}
