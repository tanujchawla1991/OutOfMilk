package com.example.outofmilk.model;

public class CartDataModel {
	private int id;
	private String item_name;
    private int quantity;
    private String consume_date;
 
    public CartDataModel(int id, String item_name, int quantity, String consume_date) {
        this.id = id;
    	this.item_name = item_name;
        this.quantity = quantity;
        this.consume_date = consume_date;
    }
 
    public int getId() {
        return id;
    }
 
    public void setId(int id) {
        this.id = id;
    }
    
    public String getItemName() {
        return item_name;
    }
 
    public void setItemName(String item_name) {
        this.item_name = item_name;
    }
    
    public int getQuantity() {
        return quantity;
    }
 
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    
    public String getDate() {
        return consume_date;
    }
 
    public void setDate(String consume_date) {
        this.consume_date = consume_date;
    }
    
}