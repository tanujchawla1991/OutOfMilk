package com.example.outofmilk.app.dialogs;

import android.app.Activity;
import android.app.Dialog;
import android.os.Bundle;
import android.view.Window;
import android.widget.Button;
import android.widget.NumberPicker;

import com.example.outofmilk.R;

public class QuantityDialog extends Dialog{
	public Activity c;
	NumberPicker n1;
	Button b1,b2;
	
	public QuantityDialog(Activity a) {
		super(a);
		// TODO Auto-generated constructor stub
		this.c=a;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.dialog_quantity);
		n1=(NumberPicker)findViewById(R.id.numberPicker1);
		b1 = (Button) findViewById(R.id.button1);
		b2 = (Button) findViewById(R.id.button2);
		
		n1.setMinValue(0);
		n1.setValue(1);
		n1.setMaxValue(20);
	}
	
}
