package com.example.outofmilk.app.activities;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DecimalFormat;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.outofmilk.R;
import com.example.outofmilk.model.Estimate;
import com.example.outofmilk.model.Store;
import com.example.outofmilk.util.DBAdapter;
import com.example.outofmilk.util.OutOfMilk;
import com.example.outofmilk.util.SendOrderEmail;

public class AcceptDecline extends Activity {
	ImageView iv1;
	TextView t1,t2,t3,t4;
	Button b1;
	
	DBAdapter db;

	InputStream is=null;
	String result=null;
	String result01=null;
	String line=null;

	Store selected_store;
	Estimate selected_estimate;

	OutOfMilk outOfMilk;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_accept_decline);
		
		outOfMilk =(OutOfMilk)getApplicationContext();

		View actionBar = findViewById(R.id.actionBar);
		TextView title = (TextView) actionBar.findViewById(R.id.title);
		title.setText("Place Order");
		ImageButton right=(ImageButton)actionBar.findViewById(R.id.right);
		right.setImageResource(R.drawable.home);
		right.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent i = new Intent(AcceptDecline.this, MenuPage.class);
				finish();
				startActivity(i);
			}
		});

		ImageButton left=(ImageButton)actionBar.findViewById(R.id.left);
		left.setImageResource(R.drawable.back);
		left.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
				Toast.makeText(AcceptDecline.this, "Your order has been cancelled.", Toast.LENGTH_LONG).show();
				onBackPressed();
			}
		});

		if (!outOfMilk.isTablet(this))
		    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

		db=new DBAdapter(this);

		selected_estimate = (Estimate)getIntent().getSerializableExtra("selected_estimate");
		selected_store = (Store)getIntent().getSerializableExtra("selected_store");

		iv1=(ImageView)findViewById(R.id.imageView1);
		t1=(TextView)findViewById(R.id.textView1);
		t2=(TextView)findViewById(R.id.textView2);
		t3=(TextView)findViewById(R.id.textView3);
		t4=(TextView)findViewById(R.id.textView4);
		b1=(Button)findViewById(R.id.button1);

		if(selected_store.getName().equalsIgnoreCase("7 Eleven"))
		{
			iv1.setImageResource(R.drawable.seveneleven);
		}
		if(selected_store.getName().equalsIgnoreCase("ShopRite"))
		{
			iv1.setImageResource(R.drawable.shoprite);
		}
		
		t1.setText(selected_store.getAddress());
		t2.setText("Price: $"+selected_estimate.getDiscounted_price());

		String discount_percentage=((selected_estimate.getOriginal_price()-selected_estimate.getDiscounted_price())/selected_estimate.getOriginal_price())*100+"";

		t3.setText("Discount: " + new DecimalFormat("#0").format(Double.parseDouble(discount_percentage)) + "%");

		b1.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				boolean y=outOfMilk.isInternetOn(getBaseContext());
	    		if(!y)
	    		{
	    		    Toast.makeText(AcceptDecline.this, "No Internet Access. Please Check Your Data Settings and Reload The App.", Toast.LENGTH_LONG).show();
	    		    return;
	    		}
	    		
	    		new Accept().execute();
	            
			}
		});
		
	}

	private class Accept extends AsyncTask<Void, Void, Void>
		{
        ProgressDialog pdLoading = new ProgressDialog(AcceptDecline.this);

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
			pdLoading.setMessage("\tPlacing Order...");
			pdLoading.show();
			pdLoading.setCancelable(false);
			pdLoading.setCanceledOnTouchOutside(false);
        }
        @Override
        protected Void doInBackground(Void... params) {
			result01=search();
			return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);

			pdLoading.dismiss();
            if(result01.indexOf("Order Placed")>-1)
            {
            	Toast.makeText(getApplicationContext(), "Your order has been placed.\nYou will recieve an email and text confirmation shortly.", Toast.LENGTH_LONG).show();
            	Sending(outOfMilk.getOrder(), outOfMilk.getUser().getEmail());
				SmsManager sms = SmsManager.getDefault();
				sms.sendTextMessage(outOfMilk.getUser().getContact(), null, "Order Confirmed\nPrice: $" + selected_estimate.getDiscounted_price() + "\n Store: " + selected_store.getName() + "\n", null, null);

				db.open();

				if(selected_estimate.getLoyalty_ranking()>selected_estimate.getCost_ranking())
				{
					if(selected_estimate.getLoyalty_index()<10)
					{
						db.updateStore(selected_estimate.getStore_id(),selected_estimate.getLoyalty_index()+1,selected_estimate.getWeight_num()+(selected_estimate.getWeight_num()*.1),selected_estimate.getWeight_den());
						db.updateOtherStores(selected_estimate.getStore_id());
					}
					else
						db.updateStore(selected_estimate.getStore_id(), selected_estimate.getLoyalty_index(), selected_estimate.getWeight_num()+(selected_estimate.getWeight_num()*.1),selected_estimate.getWeight_den());
				}
				else
				{
					if(selected_estimate.getLoyalty_index()<10)
					{
						db.updateStore(selected_estimate.getStore_id(),selected_estimate.getLoyalty_index()+1,selected_estimate.getWeight_num(),selected_estimate.getWeight_den()+(selected_estimate.getWeight_den()*.1));
						db.updateOtherStores(selected_estimate.getStore_id());
					}
					else
						db.updateStore(selected_estimate.getStore_id(), selected_estimate.getLoyalty_index(), selected_estimate.getWeight_num(),selected_estimate.getWeight_den()+(selected_estimate.getWeight_den()*.1));
				}

				db.deleteAllItems();
                db.close();
				outOfMilk.getEstimates().clear();
                Intent intent = new Intent(AcceptDecline.this, MenuPage.class);
	            finish();
	            startActivity(intent);
            }
            else
            {
				Toast.makeText(getApplicationContext(), "Sorry, something went wrong.\nPlease try again", Toast.LENGTH_LONG).show();
				Intent intent = new Intent(AcceptDecline.this, Cart.class);
				finish();
				startActivity(intent);
			}
        }
    }
    
    public String search()
    {
		try
		{
			int index=outOfMilk.getOrder().indexOf(";");
			String order=outOfMilk.getOrder().substring(index+1);
			String temp_url= outOfMilk.getUrl()+"/place_order?user_id="+outOfMilk.getUser().getId()+"&store_id="+selected_store.getId()+"&estimate="+selected_estimate.getDiscounted_price()+"&order="+order;
			URL url= new URL(temp_url.replace(" ", "%20"));
			HttpURLConnection conn=(HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");

			is=conn.getInputStream();

			Log.e("Pass 1", "connection success ");
		}
        catch(Exception e)
    	{
        	Log.e("Fail 1", e.toString());
    	}     
        
        try
        {
         	BufferedReader reader = new BufferedReader
			(new InputStreamReader(is,"iso-8859-1"),8);
            StringBuilder sb = new StringBuilder();
            while ((line = reader.readLine()) != null)
            {
       		    sb.append(line + "\n");
           	}
            is.close();
            result = sb.toString();
	        Log.e("pass 2", "connection success ");
        }
        catch(Exception e)
    	{
        	Log.e("Fail 2", e.toString());
    	}     

        Log.e("Result", result);
        return result;
    }
	
	public void Sending(String t,String email_id)
	{
		String u="Hi,\n \nYour order has been placed with: "+selected_store.getName()+"\nLocated at: "+selected_store.getAddress()+"\nFor a total price of: $"+selected_estimate.getDiscounted_price()+"\n \nThank you. It was pleasure doing business with you.\n \nAlways at your service,\nOutOfMilk";
		String v=email_id;
	    try
	    {  
	        SendOrderEmail l=new SendOrderEmail();
	        l.execute(u,v);
	    }
	    catch (Exception x)
	    {  
	        Log.e("SendMail", x.getMessage(), x);
	    }
	}
	
}
