package com.example.outofmilk.app.activities;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.location.Location;
import android.os.AsyncTask;
import android.os.Bundle;
import android.telephony.PhoneNumberFormattingTextWatcher;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.outofmilk.R;
import com.example.outofmilk.model.Store;
import com.example.outofmilk.util.DBAdapter;
import com.example.outofmilk.util.OutOfMilk;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationServices;

import org.json.JSONArray;
import org.json.JSONObject;

public class NewUser extends Activity implements GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener {
	
	EditText e1,e2,e3,e4,e5,e6,e7;
	Button b1,b2;
	Spinner s1;
	
	String imei_id;
	String name="",email="",contact="",address_l1="",address_l2="",city="",state="",zip="";
	int status;
	InputStream is=null;
	String result=null;
	String line=null;
	InputStream is1=null;
	String result1=null;
	String line1=null;

	InputStream temp_is=null;
	String temp_result=null;
	String temp_line=null;

	ArrayAdapter<String> dataAdapter1=null;
	String states[]={"State","AK","AL","AR","AZ","CA","CO","CT","DC","DE","FL","GA","GU","HI","IA","ID","IL","IN","KS","KY","LA","MA","MD","ME","MH","MI","MN","MO","MS","MT","NC","ND","NE","NH","NJ","NM","NV","NY","OH","OK","OR","PA","PR","PW","RI","SC","SD","TN","TX","UT","VA","VI","VT","WA","WI","WV","WY"};

	DBAdapter db;

    double latitude=0.0;
    double longitude=0.0;
	String address="";
	
	OutOfMilk outOfMilk;

	private final static int PLAY_SERVICES_RESOLUTION_REQUEST = 1000;

	Location mLastLocation;

	GoogleApiClient mGoogleApiClient;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_new_user);
		
		outOfMilk =(OutOfMilk)getApplicationContext();

		View actionBar = findViewById(R.id.actionBar);
		TextView title = (TextView) actionBar.findViewById(R.id.title);
		title.setText("Register User");
		ImageButton left = (ImageButton) actionBar.findViewById(R.id.left);
		left.setVisibility(View.GONE);
		ImageButton right = (ImageButton) actionBar.findViewById(R.id.right);
		right.setVisibility(View.GONE);

		if (!outOfMilk.isTablet(this))
		    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

		db=new DBAdapter(this);

		e1=(EditText)findViewById(R.id.name);
		e2=(EditText)findViewById(R.id.email);

		e3=(EditText)findViewById(R.id.phone);
		e3.addTextChangedListener(new PhoneNumberFormattingTextWatcher());

		e4=(EditText)findViewById(R.id.address_line1);
		e5=(EditText)findViewById(R.id.address_line2);
		e6=(EditText)findViewById(R.id.city);
		e7=(EditText)findViewById(R.id.zip);

		b1=(Button)findViewById(R.id.current_location);
		b2=(Button)findViewById(R.id.register);

		s1=(Spinner)findViewById(R.id.state);
		dataAdapter1 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, states);
		dataAdapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		s1.setPrompt("Select State");
		s1.setAdapter(dataAdapter1);

		TelephonyManager telephonyManager = (TelephonyManager)getSystemService(Context.TELEPHONY_SERVICE);
		imei_id=telephonyManager.getDeviceId();

		b1.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (checkPlayServices())
				{
					buildGoogleApiClient();
					mGoogleApiClient.connect();
				}
				else
				{
					Toast.makeText(getApplicationContext(), "Sorry, we have encountered a problem reading your current location.", Toast.LENGTH_LONG).show();
				}
			}
		});

		b2.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if(e1.getText().toString().equals(""))
				{
					Toast.makeText(getApplicationContext(), "Please Enter Your Full Name", Toast.LENGTH_LONG).show();
					return;
				}
				else if(e2.getText().toString().equals(""))
				{
					Toast.makeText(getApplicationContext(), "Please Enter Your Email Address", Toast.LENGTH_LONG).show();
					return;
				}
				else if (!e2.getText().toString().matches("[a-zA-Z0-9._-]+@[a-z]+\\.[a-z]+") && e2.length() > 0)
	            {
					Toast.makeText(getApplicationContext(), "Please Enter a Valid Email Address", Toast.LENGTH_LONG).show();
					return;
	            }
				else if(e3.getText().toString().equals(""))
				{
					Toast.makeText(getApplicationContext(), "Please Enter Your Contact No.", Toast.LENGTH_LONG).show();					
					return;
				}
				else if(e3.getText().toString().length()<14)
				{
					Toast.makeText(getApplicationContext(), "Please Enter a Valid Contact No.", Toast.LENGTH_LONG).show();
					return;
				}
				else if(e4.getText().toString().equals(""))
				{
					Toast.makeText(getApplicationContext(), "Please Enter Your Address", Toast.LENGTH_LONG).show();
					return;
				}
				else if(e6.getText().toString().equals(""))
				{
					Toast.makeText(getApplicationContext(), "Please Enter Your City", Toast.LENGTH_LONG).show();					
					return;
				}
				else if(s1.getSelectedItem().toString().equals("State"))
				{
					Toast.makeText(getApplicationContext(), "Please Select Your State", Toast.LENGTH_LONG).show();
					return;
				}
				else if(e7.getText().toString().equals(""))
				{
					Toast.makeText(getApplicationContext(), "Please Enter Your ZIP Code", Toast.LENGTH_LONG).show();					
					return;
				}
				
				boolean y=outOfMilk.isInternetOn(getBaseContext());
				if(!y)
				{
				    Toast.makeText(NewUser.this, "No Internet Access. Please Check Your Data Settings and Reload The App.", Toast.LENGTH_LONG).show();
				    return;
				}
				else
				{
					name=e1.getText().toString();
					email=e2.getText().toString();
					contact=e3.getText().toString().replace("(","").replace(") ","").replace("-","");
					address_l1=e4.getText().toString();
					address_l2=e5.getText().toString();
					city=e6.getText().toString();
					state=s1.getSelectedItem().toString();
					zip=e7.getText().toString();
				}
				if(latitude==0.0||longitude==0.0)
				{
					if(address_l2.equals(""))
					{
						address=address_l1 + ", " + city + ", " + state + " " + zip;
						getLatLong();
					}
					else
					{
						address=address_l1 + ", " + address_l2 + ", " + city + ", " + state + " " + zip;
						getLatLong();
					}
				}
				else
				{
					InsertAndGet();
				}
			} 
		});
		
	}

	@Override
	public void onConnected(Bundle bundle) {
		getCurrentLocation();
	}

	@Override
	public void onConnectionSuspended(int i) {
		mGoogleApiClient.connect();
	}

	@Override
	public void onConnectionFailed(ConnectionResult connectionResult) {
		Log.e("Error in GPS", "Connection failed: ConnectionResult.getErrorCode() = " + connectionResult.getErrorCode());
		return;
	}

	/**
	 * Creating google api client object
	 * */
	protected synchronized void buildGoogleApiClient() {
		mGoogleApiClient = new GoogleApiClient.Builder(this)
				.addConnectionCallbacks(this)
				.addOnConnectionFailedListener(this)
				.addApi(LocationServices.API)
				.build();
	}

	/**
	 * Method to verify google play services on the device
	 * */
	private boolean checkPlayServices() {
		int resultCode = GooglePlayServicesUtil.isGooglePlayServicesAvailable(this);
		if (resultCode != ConnectionResult.SUCCESS) {
			if (GooglePlayServicesUtil.isUserRecoverableError(resultCode))
			{
				GooglePlayServicesUtil.getErrorDialog(resultCode, this, PLAY_SERVICES_RESOLUTION_REQUEST).show();
			}
			else
			{
				Toast.makeText(getApplicationContext(), "This device is not supported.", Toast.LENGTH_LONG).show();
			}
			return false;
		}
		return true;
	}

	public void getCurrentLocation()
	{
		mLastLocation = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);

		if (mLastLocation != null)
		{
			latitude = mLastLocation.getLatitude();
			longitude = mLastLocation.getLongitude();
			new ReverseGeocode().execute();
		}
		else
		{
			Toast.makeText(getApplicationContext(),"Sorry, we have encountered a problem reading your current location.", Toast.LENGTH_LONG).show();
			latitude=0.0;
			longitude=0.0;
		}

	}

	public void getLatLong()
	{
		new Geocode().execute();
	}

	public void InsertAndGet()
	{
		new InsertUser().execute();
		new GetStores().execute();
	}
	
	private class InsertUser extends AsyncTask<Void, Void, Void>
    {
        ProgressDialog pdLoading = new ProgressDialog(NewUser.this);

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
			pdLoading.setMessage("\tRegistering...");
            pdLoading.show();
			pdLoading.setCancelable(false);
			pdLoading.setCanceledOnTouchOutside(false);
        }
        @Override
        protected Void doInBackground(Void... params) {
			status=insert();
			return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
			pdLoading.dismiss();
            if(status==1)
            {
            	Toast.makeText(getApplicationContext(), "Successfully registered.", Toast.LENGTH_LONG).show();
            	Intent intent = new Intent(NewUser.this, MenuPage.class);
            	finish();
                startActivity(intent);
            }
            else {
				Toast.makeText(getApplicationContext(), "Error in registration.\nPlease Try Again Later.", Toast.LENGTH_LONG).show();
				Intent intent = new Intent(NewUser.this, NewUser.class);
				finish();
				startActivity(intent);
			}
        }
    }
    
    public int insert()
    {
		try
		{
			String temp_url;
			if(address_l2.equals(""))
			{
				temp_url= outOfMilk.getUrl()+"/insert_user?imei_id="+imei_id+"&name="+name+"&email="+email+"&contact="+contact+"&address="+address_l1+", "+city+", "+state+" "+zip+"&latitude="+latitude+"&longitude="+longitude;
			}
			else
			{
				temp_url= outOfMilk.getUrl()+"/insert_user?imei_id="+imei_id+"&name="+name+"&email="+email+"&contact="+contact+"&address="+address_l1+", "+address_l2+", "+city+", "+state+" "+zip+"&latitude="+latitude+"&longitude="+longitude;
			}
			Log.e("query",temp_url);
			URL url= new URL(temp_url.replace(" ", "%20"));
			HttpURLConnection conn=(HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");

			is=conn.getInputStream();

			Log.e("Pass 1", "connection success ");
		}
		catch(Exception e) {
			Log.e("Fail 1", e.toString());
		}

		try
		{
			BufferedReader reader = new BufferedReader(new InputStreamReader(is,"iso-8859-1"),8);
			StringBuilder sb = new StringBuilder();
			while ((line = reader.readLine()) != null)
			{
				sb.append(line + "\n");
			}
			is.close();
			result = sb.toString();
			Log.e("Pass 2", "connection success ");
		}
		catch(Exception e)
		{
			Log.e("Fail 2", e.toString());
		}

		try
		{
			Log.e("Result", result);
			JSONObject json_object=new JSONObject(result);
			String email=json_object.getString("email");
			if(email=="null")
			{
				return 0;
			}
			else
			{
				String id=json_object.getString("user_id");
				String name=json_object.getString("name");
				String contact=json_object.getString("contact");
				String address=json_object.getString("address");
				Double latitude=json_object.getDouble("latitude");
				Double longitude=json_object.getDouble("longitude");
				outOfMilk.getUser().setId(id);
				outOfMilk.getUser().setName(name);
				outOfMilk.getUser().setEmail(email);
				outOfMilk.getUser().setContact(contact);
				outOfMilk.getUser().setAddress(address);
				outOfMilk.getUser().setLatitude(latitude);
				outOfMilk.getUser().setLongitude(longitude);
				return 1;
			}
		}
		catch(Exception e)
		{
			Log.e("Id doesn't exist.", e.toString());
			return 0;
		}
    }

	private class GetStores extends AsyncTask<Void, Void, Void>
	{
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
		}

		@Override
		protected Void doInBackground(Void... params) {
			stores();
			return null;
		}

		@Override
		protected void onPostExecute(Void result) {
			super.onPostExecute(result);
		}
	}

	public void stores()
	{
		try
		{
			String temp_url= outOfMilk.getUrl()+"/get_stores?latitude="+latitude+"&longitude="+longitude;
			URL url= new URL(temp_url.replace(" ", "%20"));
			HttpURLConnection conn=(HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");

			is1=conn.getInputStream();

			Log.e("Pass 1", "connection success ");
		}
		catch(Exception e) {
			Log.e("Fail 1", e.toString());
		}

		try
		{
			BufferedReader reader = new BufferedReader(new InputStreamReader(is1,"iso-8859-1"),8);
			StringBuilder sb = new StringBuilder();
			while ((line1 = reader.readLine()) != null)
			{
				sb.append(line1 + "\n");
			}
			is1.close();
			result1 = sb.toString();
			Log.e("Pass 2", "connection success ");
		}
		catch(Exception e)
		{
			Log.e("Fail 2", e.toString());
		}

		try
		{
			Log.e("Result", result1);
			JSONArray json_array=new JSONArray(result1);
			db.open();
			db.deleteAllStores();
			db.close();
			for(int i=0;i<json_array.length();i++)
			{
				JSONObject json_object = json_array.getJSONObject(i);
				Store store=new Store();
				store.setId(json_object.getInt("store_id"));
				store.setName(json_object.getString("name"));
				store.setAddress(json_object.getString("address"));
				store.setLatitude(json_object.getDouble("latitude"));
				store.setLongitude(json_object.getDouble("longitude"));
				Double temp_distance=0.0;
				try
				{
					String temp_url= "https://maps.googleapis.com/maps/api/distancematrix/json?origins="+latitude+","+longitude+"&destinations="+json_object.getDouble("latitude")+","+json_object.getDouble("longitude")+"&units=imperial&key="+outOfMilk.getKey();
					URL url= new URL(temp_url.replace(" ", "%20"));
					HttpURLConnection conn=(HttpURLConnection) url.openConnection();
					conn.setRequestMethod("GET");
					temp_is=conn.getInputStream();

					BufferedReader temp_reader = new BufferedReader(new InputStreamReader(temp_is,"iso-8859-1"),8);
					StringBuilder temp_sb = new StringBuilder();
					while ((temp_line = temp_reader.readLine()) != null)
					{
						temp_sb.append(temp_line + "\n");
					}
					temp_is.close();
					temp_result = temp_sb.toString();
					JSONObject temp_object=new JSONObject(temp_result);
					JSONArray temp_array=temp_object.getJSONArray("rows");
					JSONObject temp1_object=temp_array.getJSONObject(0);
					JSONArray temp1_array=temp1_object.getJSONArray("elements");
					JSONObject temp2_object=temp1_array.getJSONObject(0);
					JSONObject temp3_object=temp2_object.getJSONObject("distance");
					temp_distance=temp3_object.getDouble("value")/(1000*1.60934);
				}
				catch(Exception e)
				{
					Log.e("Error",e.toString());
					Log.e("Error","Error in getting distance.");
				}
				store.setDistance(temp_distance);
				store.setLoyalty_index(1);
				store.setWeight_num(1.0);
				store.setWeight_den(1.0);
				Log.e("Distance",store.getDistance()+"");
				if(temp_distance<=20)
				{
					db.open();
					db.insertStore(store.getId(), store.getName(), store.getAddress(), store.getLatitude(), store.getLongitude(), store.getDistance(), store.getLoyalty_index(), store.getWeight_num(), store.getWeight_den());
					db.close();
				}
			}
		}
		catch(Exception e)
		{
			Log.e("Stores doesn't exist.", e.toString());
		}
	}

	private class Geocode extends AsyncTask<Void, Void, Void>
	{
		ProgressDialog pdLoading = new ProgressDialog(NewUser.this);

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			pdLoading.setMessage("\tGetting latitude and longitude...");
			pdLoading.show();
			pdLoading.setCancelable(false);
			pdLoading.setCanceledOnTouchOutside(false);
		}
		@Override
		protected Void doInBackground(Void... params) {
			status=addresstolatlong();
			return null;
		}

		@Override
		protected void onPostExecute(Void result) {
			super.onPostExecute(result);
			pdLoading.dismiss();
			if(status==1)
			{
				InsertAndGet();
			}
			else
			{
				Toast.makeText(getApplicationContext(), "Error in parsing the address.\nPlease make sure the address is correct.", Toast.LENGTH_LONG).show();
			}
		}
	}

	public int addresstolatlong()
	{
		try
		{
			String temp_url;
			temp_url= "https://maps.googleapis.com/maps/api/geocode/json?address="+address+"&key="+outOfMilk.getKey();
			URL url= new URL(temp_url.replace(" ", "%20"));
			HttpURLConnection conn=(HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");

			is=conn.getInputStream();

			Log.e("Pass 1", "connection success ");
		}
		catch(Exception e) {
			Log.e("Fail 1", e.toString());
		}

		try
		{
			BufferedReader reader = new BufferedReader(new InputStreamReader(is,"iso-8859-1"),8);
			StringBuilder sb = new StringBuilder();
			while ((line = reader.readLine()) != null)
			{
				sb.append(line + "\n");
			}
			is.close();
			result = sb.toString();
			Log.e("Pass 2", "connection success ");
		}
		catch(Exception e)
		{
			Log.e("Fail 2", e.toString());
		}

		try
		{
			Log.e("Result", result);

			JSONObject temp_object=new JSONObject(result);
			JSONArray temp_array=temp_object.getJSONArray("results");
			JSONObject temp1_object=temp_array.getJSONObject(0);
			JSONObject temp2_object=temp1_object.getJSONObject("geometry");
			JSONObject temp3_object=temp2_object.getJSONObject("location");
			latitude=Double.parseDouble(temp3_object.getString("lat"));
			longitude=Double.parseDouble(temp3_object.getString("lng"));
			return 1;
		}
		catch(Exception e)
		{
			Log.e("Id doesn't exist.", e.toString());
			return 0;
		}
	}

	private class ReverseGeocode extends AsyncTask<Void, Void, Void>
	{
		ProgressDialog pdLoading = new ProgressDialog(NewUser.this);

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			pdLoading.setMessage("\tGetting current address...");
			pdLoading.show();
			pdLoading.setCancelable(false);
			pdLoading.setCanceledOnTouchOutside(false);
		}
		@Override
		protected Void doInBackground(Void... params) {
			status=latlongtoaddress();
			return null;
		}

		@Override
		protected void onPostExecute(Void result) {
			super.onPostExecute(result);
			pdLoading.dismiss();
			if(status==1)
			{
				try
				{
					String arr[]=address.split(",");
					address_l1=arr[0];
					if(arr.length-3==1)
					{
						address_l2="";
					}
					else
					{
						address_l2=arr[1];
					}
					city=arr[arr.length-3].replaceFirst(" ","");
					String temp[]=arr[arr.length-2].replaceFirst(" ","").split(" ");
					state=temp[0];
					zip=temp[1];

					e4.setText(address_l1);
					e5.setText(address_l2);
					e6.setText(city);
					e7.setText(zip);
					s1.setSelection(dataAdapter1.getPosition(state));
				}
				catch(Exception e)
				{
					Log.e("Error","Error in setting the fields using the current location.");
					Toast.makeText(getApplicationContext(), "Sorry, we have encountered a problem reading your current location.", Toast.LENGTH_LONG).show();
					e4.setText("");
					e5.setText("");
					e6.setText("");
					e7.setText("");
					s1.setSelection(0);
				}
			}
			else
			{
				Toast.makeText(getApplicationContext(), "Sorry, we have encountered a problem reading your current location.", Toast.LENGTH_LONG).show();
				e4.setText("");
				e5.setText("");
				e6.setText("");
				e7.setText("");
				s1.setSelection(0);
			}
		}
	}

	public int latlongtoaddress()
	{
		try
		{
			String temp_url;
			temp_url= "https://maps.googleapis.com/maps/api/geocode/json?latlng="+latitude+","+longitude+"&key="+outOfMilk.getKey();
			URL url= new URL(temp_url.replace(" ", "%20"));
			HttpURLConnection conn=(HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");

			is=conn.getInputStream();

			Log.e("Pass 1", "connection success ");
		}
		catch(Exception e)
		{
			Log.e("Fail 1", e.toString());
		}

		try
		{
			BufferedReader reader = new BufferedReader(new InputStreamReader(is,"iso-8859-1"),8);
			StringBuilder sb = new StringBuilder();
			while ((line = reader.readLine()) != null)
			{
				sb.append(line + "\n");
			}
			is.close();
			result = sb.toString();
			Log.e("Pass 2", "connection success ");
		}
		catch(Exception e)
		{
			Log.e("Fail 2", e.toString());
		}

		try
		{
			Log.e("Result", result);

			JSONObject temp_object=new JSONObject(result);
			JSONArray temp_array=temp_object.getJSONArray("results");
			JSONObject temp1_object=temp_array.getJSONObject(0);
			address=temp1_object.getString("formatted_address");
			return 1;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Log.e("Id doesn't exist.", e.toString());
			return 0;
		}
	}

}
