package com.example.outofmilk.app.activities;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.outofmilk.R;
import com.example.outofmilk.model.CartDataModel;
import com.example.outofmilk.model.Estimate;
import com.example.outofmilk.util.DBAdapter;
import com.example.outofmilk.util.ListAdapter;
import com.example.outofmilk.util.OutOfMilk;

import org.json.JSONArray;
import org.json.JSONObject;

public class Cart extends Activity {

	ArrayList<CartDataModel> listArray;
    DBAdapter db;
	Button b1;
	
	String order="";
	int status;

	InputStream is=null;
	String result=null;
	String line=null;
    
	SharedPreferences prefs;
	String prefName ="MyPref";
	
	OutOfMilk outOfMilk;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_cart);
		
		outOfMilk =(OutOfMilk)getApplicationContext();

		View actionBar = findViewById(R.id.actionBar);
		TextView title = (TextView) actionBar.findViewById(R.id.title);
		title.setText("Cart");
		ImageButton right=(ImageButton)actionBar.findViewById(R.id.right);
		right.setImageResource(R.drawable.edit_user);
		right.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent i = new Intent(Cart.this, EditUser.class);
				startActivity(i);
			}
		});

		ImageButton left=(ImageButton)actionBar.findViewById(R.id.left);
		left.setImageResource(R.drawable.back);
		left.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
				onBackPressed();
			}
		});

		if (!outOfMilk.isTablet(this))
		    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
		
		b1=(Button)findViewById(R.id.button1);

		db = new DBAdapter(this);
		listArray = new ArrayList<CartDataModel>();
        db.open();
        final Cursor cursor=db.getCart();
        if (cursor.moveToFirst()) {
        	do
			{
                int cart_id=Integer.parseInt(cursor.getString(0));
        		String cart_item=cursor.getString(1);
        		int cart_quantity=Integer.parseInt(cursor.getString(2));
        		String cart_date=cursor.getString(3);
        		listArray.add(new CartDataModel(cart_id, cart_item, cart_quantity, cart_date));
        	}
			while (cursor.moveToNext());
        }
        else
        {
        	b1.setEnabled(false);
        }
        db.close();
        
        b1.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				boolean y=outOfMilk.isInternetOn(getBaseContext());
	    		if(!y)
	    		{
	    		    Toast.makeText(Cart.this, "No Internet Access. Please Check Your Data Settings and Reload The App.", Toast.LENGTH_LONG).show();
	    		    return;
	    		}

	    		db.open();
				Cursor cursor_stores;
				cursor_stores=db.getStores();
				if(cursor_stores.moveToFirst())
				{
					do
					{
						order=order+cursor_stores.getString(0)+",";
					}
					while(cursor_stores.moveToNext());
					order=order.substring(0,order.length()-1);
					order=order+";";
				}

				Cursor cursor=db.getCart();
				if (cursor.moveToFirst())
				{
					do
					{
						order=order+cursor.getString(0)+",";

						order=order+cursor.getString(2)+",";

						if(cursor.getString(3).length()==8)
						{
							order=order+cursor.getString(3).substring(0,5)+"0"+cursor.getString(3).substring(5,7)+"0"+cursor.getString(3).substring(7)+";";
						}

						if(cursor.getString(3).length()==9)
						{
							if(cursor.getString(3).indexOf("-", 5)==6)
							{
								order=order+cursor.getString(3).substring(0, 5)+"0"+cursor.getString(3).substring(5)+";";
							}
							else
							{
								order=order+cursor.getString(3).substring(0, 8)+"0"+cursor.getString(3).substring(8)+";";
							}
						}

						if(cursor.getString(3).length()==10)
						{
							order=order+cursor.getString(3)+";";
						}
			     	}
					while (cursor.moveToNext());
					order=order.substring(0,order.length()-1);

				}
		        db.close();
				outOfMilk.setOrder(order);
		        Log.e("Final Order",order);
				
		        new GetEstimate().execute();
			} 
		});
        
        ListView listView = (ListView) findViewById(R.id.listView1);		 
        ListAdapter listAdapter = new ListAdapter(listArray);
        listView.setAdapter(listAdapter);
        
	}

	private class GetEstimate extends AsyncTask<Void, Void, Void>
    {
        ProgressDialog pdLoading = new ProgressDialog(Cart.this);

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
			pdLoading.setMessage("\tEstimating Price...");
            pdLoading.show();
			pdLoading.setCancelable(false);
			pdLoading.setCanceledOnTouchOutside(false);
        }

        @Override
        protected Void doInBackground(Void... params) {
			status=estimate();
			return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
			pdLoading.dismiss();
            order="";
            if(status==1)
            {
				int j=0;

				Collections.sort(outOfMilk.getEstimates(), new Comparator<Estimate>() {
					public int compare(Estimate one, Estimate two) {
						if (one.getCost_index() > two.getCost_index()) {
							return 1;
						} else if (one.getCost_index() < two.getCost_index()) {
							return -1;
						} else {
							return 0;
						}
					}
				});

				j=outOfMilk.getEstimates().size();
				for(int i=0;i<outOfMilk.getEstimates().size();i++)
				{
					outOfMilk.getEstimates().get(i).setCost_ranking(j);
					j=j-1;
				}

				Collections.sort(outOfMilk.getEstimates(), new Comparator<Estimate>() {
					public int compare(Estimate one, Estimate two) {
						if (one.getLoyalty_index() < two.getLoyalty_index()) {
							return 1;
						} else if (one.getLoyalty_index() > two.getLoyalty_index()) {
							return -1;
						} else {
							return 0;
						}
					}
				});


				j=outOfMilk.getEstimates().size();
				for(int i=0;i<outOfMilk.getEstimates().size();i++)
				{
					outOfMilk.getEstimates().get(i).setLoyalty_ranking(j);
					j=j-1;
				}

				for(int i=0;i<outOfMilk.getEstimates().size();i++)
				{
					int li=0;
					double ci=0,wn=0,wd=0;
					li=outOfMilk.getEstimates().get(i).getLoyalty_index();
					ci=outOfMilk.getEstimates().get(i).getCost_index();
					wn=outOfMilk.getEstimates().get(i).getWeight_num();
					wd=outOfMilk.getEstimates().get(i).getWeight_den();

					double af=(li*wn)+(ci*wd);

					outOfMilk.getEstimates().get(i).setAdequacy_factor(af);
				}

				Collections.sort(outOfMilk.getEstimates(), new Comparator<Estimate>() {
					public int compare(Estimate one, Estimate two) {
						if (one.getAdequacy_factor() < two.getAdequacy_factor()) {
							return 1;
						} else if (one.getAdequacy_factor() > two.getAdequacy_factor()) {
							return -1;
						} else {
							return 0;
						}
					}
				});

				Intent intent = new Intent(Cart.this, EstimateScreen.class);
				finish();
				startActivity(intent);
            }
            else
            {
				Toast.makeText(getApplicationContext(), "Sorry, your order cannot be fulfilled.\nPlease try again at a later time.", Toast.LENGTH_LONG).show();
				db = new DBAdapter(getApplicationContext());
				db.open();
				db.deleteAllItems();
				db.close();
				Intent intent = new Intent(Cart.this, MenuPage.class);
				finish();
				startActivity(intent);
            }

        }
    }

    public int estimate()
    {
		try
		{
			String temp_url= outOfMilk.getUrl()+"/get_estimate?order="+order;
			URL url= new URL(temp_url.replace(" ", "%20"));
			HttpURLConnection conn=(HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");

			is=conn.getInputStream();

			Log.e("Pass 1", "connection success ");
		}
		catch(Exception e)
		{
			Log.e("Fail 1", e.toString());
		}

		try
		{
			BufferedReader reader = new BufferedReader(new InputStreamReader(is,"iso-8859-1"),8);
			StringBuilder sb = new StringBuilder();
			while ((line = reader.readLine()) != null)
			{
				sb.append(line + "\n");
			}
			is.close();
			result = sb.toString();
			Log.e("Pass 2", "connection success ");
		} catch (Exception e) {
			Log.e("Fail 2", e.toString());
		}

		//This is sample estimate response: result="[{\"store_id\":2,\"original_price\":\"14\",\"discounted_price\":\"10.8\"},{\"store_id\":5,\"original_price\":\"18\",\"discounted_price\":\"14\"},{\"store_id\":6,\"original_price\":\"13\",\"discounted_price\":\"7.6\"}]";

		try {
			Log.e("Result", result);
			JSONArray json_array=new JSONArray(result);
			int stop;
			if(json_array.length()<10)
			{
				stop=json_array.length();
			}
			else
			{
				stop=10;
			}
			for(int i=0;i<stop;i++)
			{
				JSONObject json_object = json_array.getJSONObject(i);
				Estimate estimate=new Estimate();
				estimate.setStore_id(json_object.getInt("store_id"));
				estimate.setOriginal_price(json_object.getDouble("original_price"));
				estimate.setDiscounted_price(json_object.getDouble("discounted_price"));
				Double discount=((json_object.getDouble("original_price")-json_object.getDouble("discounted_price"))/json_object.getDouble("original_price"))*10;
				estimate.setCost_index(discount);
				db.open();
				Cursor cursor=db.getStore(json_object.getInt("store_id"));
				if(cursor.moveToFirst()) {
					estimate.setLoyalty_index(cursor.getInt(6));
					estimate.setWeight_num(cursor.getDouble(7));
					estimate.setWeight_den(cursor.getDouble(8));
				}
				db.close();
				outOfMilk.getEstimates().add(estimate);
			}
			return 1;
		}
		catch(Exception e)
		{
			Log.e("Estimate doesn't exist.", e.toString());
			return 0;
		}
    }

}