package com.example.outofmilk.util;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBAdapter {
	static final String TAG = "DBAdapter";
	static final String DATABASE_NAME = "OutOfMilk";
	static final int DATABASE_VERSION = 1;
	
	final Context context;
	DatabaseHelper DBHelper;
	SQLiteDatabase db;

	public DBAdapter(Context ctx)
	{
		this.context = ctx;
		DBHelper = new DatabaseHelper(context);
	}
	
	private static class DatabaseHelper extends SQLiteOpenHelper
	{
		DatabaseHelper(Context context)
		{
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
		}

		@Override
		public void onCreate(SQLiteDatabase db)
		{

		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
		{

		}
	}
	
	public DBAdapter open() throws SQLException
	{
		db = DBHelper.getWritableDatabase();
		return this;
	}

	public void close()
	{
		DBHelper.close();
	}
	
	public Cursor getCart()
	{
		return db.query("cart", null, null, null, null, null, null);
	}

	public boolean deleteAllItems()
	{
		return db.delete("cart", "1", null)>0;
	}
	
	public boolean deleteItem(int id)
	{
		return db.delete("cart", "id=" + id, null)>0;
	}
	
	public long insertToCart(int id, String item, int quantity, String date)
	{
		ContentValues initialValues = new ContentValues();
		initialValues.put("id", id);
		initialValues.put("item", item);
		initialValues.put("quantity", quantity);
		initialValues.put("date", date);
		return db.insert("cart", null, initialValues);
	}

	public Cursor getStore(int store_id)
	{
		return db.query("stores", null, "id=?", new String[]{store_id + ""}, null, null, null);
	}

	public Cursor getStores()
	{
		return db.query("stores", null, null, null, null, null, null);
	}

	public long insertStore(int id, String name, String address, double latitude, double longitude, double distance, int loyalty_index, double weight_num, double weight_den)
	{
		ContentValues initialValues = new ContentValues();
		initialValues.put("id", id);
		initialValues.put("name", name);
		initialValues.put("address", address);
		initialValues.put("latitude", latitude);
		initialValues.put("longitude", longitude);
		initialValues.put("distance", distance);
		initialValues.put("loyalty_index", loyalty_index);
		initialValues.put("weight_num", weight_num);
		initialValues.put("weight_den", weight_den);
		return db.insert("stores", null, initialValues);
	}

	public int updateStore(int id, int loyalty_index, double weight_num, double weight_den)
	{
		ContentValues initialValues = new ContentValues();
		initialValues.put("loyalty_index", loyalty_index);
		initialValues.put("weight_num", weight_num);
		initialValues.put("weight_den", weight_den);
		return db.update("stores", initialValues, "id=" + id, null);
	}

	public void updateOtherStores(int id)
	{
		db.execSQL("UPDATE stores SET loyalty_index=loyalty_index-1 WHERE id!="+id+" AND loyalty_index>1");
	}

	public boolean deleteAllStores()
	{
		return db.delete("stores", "1", null)>0;
	}
}
