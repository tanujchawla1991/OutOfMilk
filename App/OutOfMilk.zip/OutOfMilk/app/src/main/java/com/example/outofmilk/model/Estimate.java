package com.example.outofmilk.model;

import java.io.Serializable;

public class Estimate implements Serializable{
    int store_id;
    double original_price;
    double discounted_price;
    double cost_index;
    int cost_ranking;
    int loyalty_index;
    int loyalty_ranking;
    double weight_num;
    double weight_den;
    double adequacy_factor;

    public int getStore_id() {
        return store_id;
    }

    public void setStore_id(int store_id) {
        this.store_id = store_id;
    }

    public double getOriginal_price() {
        return original_price;
    }

    public void setOriginal_price(double original_price) {
        this.original_price = original_price;
    }

    public double getDiscounted_price() {
        return discounted_price;
    }

    public void setDiscounted_price(double discounted_price) {
        this.discounted_price = discounted_price;
    }

    public double getCost_index() {
        return cost_index;
    }

    public void setCost_index(double cost_index) {
        this.cost_index = cost_index;
    }

    public int getCost_ranking() {
        return cost_ranking;
    }

    public void setCost_ranking(int cost_ranking) {
        this.cost_ranking = cost_ranking;
    }

    public int getLoyalty_index() {
        return loyalty_index;
    }

    public void setLoyalty_index(int loyalty_index) {
        this.loyalty_index = loyalty_index;
    }

    public int getLoyalty_ranking() {
        return loyalty_ranking;
    }

    public void setLoyalty_ranking(int loyalty_ranking) {
        this.loyalty_ranking = loyalty_ranking;
    }

    public double getWeight_num() {
        return weight_num;
    }

    public void setWeight_num(double weight_num) {
        this.weight_num = weight_num;
    }

    public double getWeight_den() {
        return weight_den;
    }

    public void setWeight_den(double weight_den) {
        this.weight_den = weight_den;
    }

    public double getAdequacy_factor() {
        return adequacy_factor;
    }

    public void setAdequacy_factor(double adequacy_factor) {
        this.adequacy_factor = adequacy_factor;
    }
}
