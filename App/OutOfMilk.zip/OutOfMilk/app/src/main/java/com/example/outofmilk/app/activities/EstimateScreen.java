package com.example.outofmilk.app.activities;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import com.example.outofmilk.R;
import com.example.outofmilk.model.Estimate;
import com.example.outofmilk.model.Store;
import com.example.outofmilk.util.DBAdapter;
import com.example.outofmilk.util.ListAdapter1;
import com.example.outofmilk.util.OutOfMilk;

import java.util.ArrayList;

public class EstimateScreen extends Activity {

    ArrayList<Estimate> listArray=null;

    DBAdapter db;

    OutOfMilk outOfMilk;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_estimate_screen);

        outOfMilk =(OutOfMilk)getApplicationContext();

        View actionBar = findViewById(R.id.actionBar);
        TextView title = (TextView) actionBar.findViewById(R.id.title);
        title.setText("Estimates");
        ImageButton right=(ImageButton)actionBar.findViewById(R.id.right);
        right.setImageResource(R.drawable.home);
        right.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(EstimateScreen.this, MenuPage.class);
                finish();
                startActivity(i);
            }
        });

        ImageButton left=(ImageButton)actionBar.findViewById(R.id.left);
        left.setImageResource(R.drawable.back);
        left.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                onBackPressed();
            }
        });

        if (!outOfMilk.isTablet(this))
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        listArray=new ArrayList<Estimate>();

        listArray=outOfMilk.getEstimates();


        ListView listView = (ListView) findViewById(R.id.listView1);
        final ListAdapter1 listAdapter = new ListAdapter1(listArray);
        listView.setAdapter(listAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Estimate selected_estimate=new Estimate();
                selected_estimate.setStore_id(listArray.get(position).getStore_id());
                selected_estimate.setOriginal_price(listArray.get(position).getOriginal_price());
                selected_estimate.setDiscounted_price(listArray.get(position).getDiscounted_price());
                selected_estimate.setCost_index(listArray.get(position).getCost_index());
                selected_estimate.setCost_ranking(listArray.get(position).getCost_ranking());
                selected_estimate.setLoyalty_index(listArray.get(position).getLoyalty_index());
                selected_estimate.setLoyalty_ranking(listArray.get(position).getLoyalty_ranking());
                selected_estimate.setWeight_num(listArray.get(position).getWeight_num());
                selected_estimate.setWeight_den(listArray.get(position).getWeight_den());
                selected_estimate.setAdequacy_factor(listArray.get(position).getAdequacy_factor());

                Store selected_store=new Store();

                db=new DBAdapter(view.getContext());
                db.open();
                Cursor cursor=db.getStore(listArray.get(position).getStore_id());
                if(cursor.moveToFirst())
                {
                    selected_store.setId(cursor.getInt(0));
                    selected_store.setName(cursor.getString(1));
                    selected_store.setAddress(cursor.getString(2));
                    selected_store.setLatitude(cursor.getDouble(3));
                    selected_store.setLongitude(cursor.getDouble(4));
                    selected_store.setDistance(cursor.getDouble(5));
                    selected_store.setLoyalty_index(cursor.getInt(6));
                    selected_store.setWeight_num(cursor.getDouble(7));
                    selected_store.setWeight_den(cursor.getDouble(8));
                }
                db.close();

                Intent intent = new Intent(EstimateScreen.this, AcceptDecline.class);

                Bundle mBundle = new Bundle();
                mBundle.putSerializable("selected_estimate", selected_estimate);
                mBundle.putSerializable("selected_store", selected_store);

                intent.putExtras(mBundle);
                startActivity(intent);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_estimate_screen, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
