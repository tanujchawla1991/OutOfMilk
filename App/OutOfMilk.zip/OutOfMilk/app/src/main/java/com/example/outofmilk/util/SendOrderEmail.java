package com.example.outofmilk.util;

import android.os.AsyncTask;
import android.util.Log;

import com.example.outofmilk.util.GMailSender;

public class SendOrderEmail extends AsyncTask<String, Void, Void>{
	@Override
	protected Void doInBackground(String... param) {
        if (isCancelled()) return null;
        try
        {
        	GMailSender sender = new GMailSender("-->Sender Email Goes Here<--","-->Sender Password Goes Here<--");
        	sender.sendMail("OutOfMilk","OutOfMilk Order",param[0],"-->Sender Email Goes Here<--",param[1]);
        }
        catch(Exception e)
        {
        	Log.e("error",e.getMessage(),e);
        }
		return null;
	}

}
