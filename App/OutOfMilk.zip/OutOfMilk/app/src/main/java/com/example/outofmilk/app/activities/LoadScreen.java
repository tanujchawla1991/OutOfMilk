package com.example.outofmilk.app.activities;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import org.json.JSONObject;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.Toast;

import com.example.outofmilk.R;
import com.example.outofmilk.util.OutOfMilk;

public class LoadScreen extends Activity {

	String imei_id;
	int status;
	InputStream is=null;
	String result=null;
	String line=null;
	SharedPreferences prefs;
	String prefName ="MyPref";
	OutOfMilk outOfMilk;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_load_screen);

		outOfMilk = (OutOfMilk) getApplicationContext();

		if (!outOfMilk.isTablet(this))
			setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

		outOfMilk.setUpDatabase();

		prefs = getSharedPreferences(prefName, MODE_PRIVATE);
		SharedPreferences.Editor editor = prefs.edit();
		editor.putInt("Check_Cart", 0);
		editor.commit();

		int DELAY = 2000;
		Handler handler = new Handler();
		handler.postDelayed(new Runnable() {
			@Override
			public void run() {
				boolean y = outOfMilk.isInternetOn(getBaseContext());
				if (!y) {
					Toast.makeText(LoadScreen.this, "No Internet Access. Please Check Your Data Settings and Reload The App.", Toast.LENGTH_LONG).show();
					return;
				}

				TelephonyManager telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
				imei_id = telephonyManager.getDeviceId();
				new AuthenticateUser().execute();
			}
		}, DELAY);
	}

	private class AuthenticateUser extends AsyncTask<Void, Void, Void>
    {
        ProgressDialog pdLoading = new ProgressDialog(LoadScreen.this);

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
			pdLoading.setMessage("\tFetching Profile...");
            pdLoading.show();
			pdLoading.setCancelable(false);
			pdLoading.setCanceledOnTouchOutside(false);
        }

		@Override
        protected Void doInBackground(Void... params) {
			status=authenticate();
			return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
			pdLoading.dismiss();
            if(status==1)
            {
            	Toast.makeText(getApplicationContext(), "Welcome Back "+outOfMilk.getUser().getName()+".\nIt's good to see you again.", Toast.LENGTH_LONG).show();
        	    Intent intent = new Intent(LoadScreen.this, MenuPage.class);
            	finish();
                startActivity(intent);
            }
            else
            {
            	Toast.makeText(getApplicationContext(), "Please Continue With One Time Registration.", Toast.LENGTH_LONG).show();
            	Intent intent = new Intent(LoadScreen.this, NewUser.class);
            	finish();
                startActivity(intent);
            }
        }
    }

    public int authenticate()
    {
		try
		{
			String temp_url= outOfMilk.getUrl()+"/authenticate_user?imei_id="+imei_id;
			URL url= new URL(temp_url.replace(" ", "%20"));
			HttpURLConnection conn=(HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");

			is=conn.getInputStream();

			Log.e("Pass 1", "connection success ");
		}
		catch(Exception e)
		{
			Log.e("Fail 1", e.toString());
		}

		try
		{
			BufferedReader reader = new BufferedReader(new InputStreamReader(is,"iso-8859-1"),8);
			StringBuilder sb = new StringBuilder();
			while ((line = reader.readLine()) != null)
			{
				sb.append(line + "\n");
			}
			is.close();
			result = sb.toString();
			Log.e("Pass 2", "connection success ");
		}
		catch(Exception e)
		{
			Log.e("Fail 2", e.toString());
		}

		try
		{
			Log.e("Result", result);
			JSONObject json_object=new JSONObject(result);
			String email=json_object.getString("email");
			if(email=="null")
			{
				return 0;
			}
			else
			{
				String id=json_object.getString("user_id");
				String name=json_object.getString("name");
				String contact=json_object.getString("contact");
				String address=json_object.getString("address");
				Double latitude=json_object.getDouble("latitude");
				Double longitude=json_object.getDouble("longitude");
				outOfMilk.getUser().setId(id);
				outOfMilk.getUser().setName(name);
				outOfMilk.getUser().setEmail(email);
				outOfMilk.getUser().setContact(contact);
				outOfMilk.getUser().setAddress(address);
				outOfMilk.getUser().setLatitude(latitude);
				outOfMilk.getUser().setLongitude(longitude);
				return 1;
			}
		}
		catch(Exception e)
		{
			Log.e("Id doesn't exist.", e.toString());
			return 0;
		}
    }
	
}