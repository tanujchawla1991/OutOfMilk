package com.example.outofmilk.app.dialogs;

import android.app.Activity;
import android.app.Dialog;
import android.os.Bundle;
import android.view.Window;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.Toast;

import com.example.outofmilk.R;

public class DateDialog extends Dialog{
	public Activity c;
	DatePicker d1;
	Button b1,b2;
	
	public DateDialog(Activity a) {
		super(a);
		// TODO Auto-generated constructor stub
		this.c=a;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.dialog_date);
		
		//Toast.makeText(getContext(), "Enter a date within 10 days from now.", Toast.LENGTH_SHORT).show();
		d1=(DatePicker)findViewById(R.id.datePicker1);
		b1 = (Button) findViewById(R.id.button1);
		b2 = (Button) findViewById(R.id.button2);
	}
	
}
