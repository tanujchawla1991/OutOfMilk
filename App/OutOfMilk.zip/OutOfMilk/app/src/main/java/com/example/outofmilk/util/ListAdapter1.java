package com.example.outofmilk.util;

import java.text.DecimalFormat;
import java.util.ArrayList;

import android.database.Cursor;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.outofmilk.R;
import com.example.outofmilk.model.Estimate;

public class ListAdapter1 extends BaseAdapter {
    ArrayList<Estimate> listArray;
    DBAdapter db;

    public ListAdapter1(ArrayList<Estimate> listArray) {
        this.listArray = listArray;
    }

    @Override
    public int getCount() {
        return listArray.size();    // total number of elements in the list
    }

    @Override
    public Object getItem(int i) {
        return listArray.get(i);    // single item in the list
    }

    @Override
    public long getItemId(int i) {
        return i;                   // index number
    }

    @Override
    public View getView(final int index, View view, final ViewGroup parent) {

        if (view == null) {
            LayoutInflater inflater = LayoutInflater.from(parent.getContext());
            view = inflater.inflate(R.layout.estimate_item, parent, false);
        }

        final Estimate dataModel = listArray.get(index);

        TextView textView1 = (TextView) view.findViewById(R.id.textView1);
        TextView textView2 = (TextView) view.findViewById(R.id.textView2);
        TextView textView3 = (TextView) view.findViewById(R.id.textView3);
        TextView textView4 = (TextView) view.findViewById(R.id.textView4);

        textView1.setText(dataModel.getDiscounted_price()+"");
        String discount_percentage=((dataModel.getOriginal_price()-dataModel.getDiscounted_price())/dataModel.getOriginal_price())*100+"";

        textView2.setText(new DecimalFormat("#0").format(Double.parseDouble(discount_percentage))+"% Off");

        String store_name="";
        db=new DBAdapter(parent.getContext());
        db.open();
        Cursor cursor=db.getStore(dataModel.getStore_id());
        if(cursor.moveToFirst())
        {
            textView3.setText(cursor.getString(2));
            store_name=cursor.getString(1);
            textView4.setText(new DecimalFormat("#0.00").format(cursor.getDouble(5)) + " miles");
        }
        db.close();

        ImageView imageView2 = (ImageView) view.findViewById(R.id.imageView2);
        if(store_name.equalsIgnoreCase("7 Eleven"))
        {
            imageView2.setImageResource(R.drawable.seveneleven);
        }
        else if(store_name.equalsIgnoreCase("ShopRite"))
        {
            imageView2.setImageResource(R.drawable.shoprite);
        }

        return view;
    }

}