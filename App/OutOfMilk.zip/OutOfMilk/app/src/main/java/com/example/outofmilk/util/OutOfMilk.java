package com.example.outofmilk.util;

import android.app.Application;
import android.content.Context;
import android.content.res.Configuration;
import android.net.ConnectivityManager;

import com.example.outofmilk.model.Estimate;
import com.example.outofmilk.model.Store;
import com.example.outofmilk.model.User;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;

public class OutOfMilk extends Application{
    private String key="Your Google API key with Geocoding and Distance Matrix API activated similar to one shown in comments below";
	private String url="Your Server URL as shown in comments below";
	//private String key="AIzaSyDiHIgFuS_Znnym-PaitePgOJhyD7yPUgc";
	//private String url="http://ec2-52-10-235-125.us-west-2.compute.amazonaws.com:8080/OutOfMilk";
	private User user=new User();
	private ArrayList<Estimate> estimates=new ArrayList<Estimate>();
	private String order="";

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public ArrayList<Estimate> getEstimates() {
		return estimates;
	}

	public void setEstimates(ArrayList<Estimate> estimates) {
		this.estimates = estimates;
	}

	public String getOrder() {
		return order;
	}

	public void setOrder(String order) {
		this.order = order;
	}

	public boolean isTablet(Context context) {
		return (context.getResources().getConfiguration().screenLayout & Configuration.SCREENLAYOUT_SIZE_MASK) >= Configuration.SCREENLAYOUT_SIZE_LARGE;
	}

	public boolean isInternetOn(Context context)
	{
		ConnectivityManager connec =(ConnectivityManager)getSystemService(context.CONNECTIVITY_SERVICE);

		if ( connec.getNetworkInfo(0).getState() == android.net.NetworkInfo.State.CONNECTED ||
				connec.getNetworkInfo(0).getState() == android.net.NetworkInfo.State.CONNECTING ||
				connec.getNetworkInfo(1).getState() == android.net.NetworkInfo.State.CONNECTING ||
				connec.getNetworkInfo(1).getState() == android.net.NetworkInfo.State.CONNECTED )
		{
			return true;

		} else if (
				connec.getNetworkInfo(0).getState() == android.net.NetworkInfo.State.DISCONNECTED ||
						connec.getNetworkInfo(1).getState() == android.net.NetworkInfo.State.DISCONNECTED  )
		{

			return false;
		}
		return false;
	}

	public void setUpDatabase()
	{
		String destDir = "/data/data/" + getPackageName() +"/databases/";
		String destPath = destDir + "OutOfMilk";
		File f = new File(destPath);
		if (!f.exists())
		{
			//---make sure directory exists---
			File directory = new File(destDir);
			directory.mkdirs();

			//---copy the db from the assets folder into the databases folder---
			try
			{
				CopyDB(getBaseContext().getAssets().open("OutOfMilk"), new FileOutputStream(destPath));
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}
	}

	public void CopyDB(InputStream inputStream, OutputStream outputStream) throws IOException
	{
		byte[] buffer = new byte[1024];
		int length;
		while ((length = inputStream.read(buffer)) > 0)
		{
			outputStream.write(buffer, 0, length);
		}
		inputStream.close();
		outputStream.close();
	}
}
