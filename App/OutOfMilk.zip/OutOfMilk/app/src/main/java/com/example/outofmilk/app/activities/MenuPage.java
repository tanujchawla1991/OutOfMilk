package com.example.outofmilk.app.activities;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.NumberPicker;
import android.widget.TextView;
import android.widget.Toast;

import com.example.outofmilk.R;
import com.example.outofmilk.app.dialogs.DateDialog;
import com.example.outofmilk.app.dialogs.PromptDialog;
import com.example.outofmilk.app.dialogs.QuantityDialog;
import com.example.outofmilk.util.DBAdapter;
import com.example.outofmilk.util.OutOfMilk;

public class MenuPage extends Activity {
	
	ImageButton ib1,ib2,ib3,ib4,ib5,ib6,ib7;
	String d1_date,d2_date;
	int quan;
	DBAdapter db;
	int check;
	SharedPreferences prefs;
	String prefName ="MyPref";

	OutOfMilk outOfMilk;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_menu);

		outOfMilk=(OutOfMilk)getApplicationContext();

		View actionBar = findViewById(R.id.actionBar);
		TextView title = (TextView) actionBar.findViewById(R.id.title);
		title.setText("Menu");
		ImageButton right=(ImageButton)actionBar.findViewById(R.id.right);
		right.setImageResource(R.drawable.cart);
		right.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent i = new Intent(MenuPage.this, Cart.class);
				startActivity(i);
			}
		});

		ImageButton left=(ImageButton)actionBar.findViewById(R.id.left);
		left.setImageResource(R.drawable.edit_user);
		left.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent i = new Intent(MenuPage.this, EditUser.class);
				startActivity(i);
			}
		});

		if (!outOfMilk.isTablet(this))
		    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
		
		prefs=getSharedPreferences(prefName, MODE_PRIVATE);
		check=prefs.getInt("Check_Cart",0);

		db = new DBAdapter(this);
		if(check==0)
		{
			db.open();
			Cursor cursor=db.getCart();
			if (cursor.moveToFirst())
			{
				Show_Prompt_Dialog();
			}
			db.close();
			prefs=getSharedPreferences(prefName, MODE_PRIVATE);
			SharedPreferences.Editor editor=prefs.edit();
			editor.remove("Check_Cart");
			editor.putInt("Check_Cart",1);
			editor.commit();
		}
		
		ib1=(ImageButton)findViewById(R.id.imageButton1);
		ib2=(ImageButton)findViewById(R.id.imageButton2);
		ib3=(ImageButton)findViewById(R.id.imageButton3);
		ib4=(ImageButton)findViewById(R.id.imageButton4);
		ib5=(ImageButton)findViewById(R.id.imageButton5);

		ib1.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				Show_Quantity_Dialog("Skim Milk");

			} 
		});
		
		ib2.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				Show_Quantity_Dialog("One Percent Milk");

			} 
		});
		
		ib3.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				Show_Quantity_Dialog("Chocolate Milk");

			} 
		});
		
		ib4.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				Show_Quantity_Dialog("Two Percent Milk");

			} 
		});
		
		ib5.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				Show_Quantity_Dialog("Regular Milk");

			} 
		});
		
	}
	
	@Override
	public void onBackPressed() {
		super.onBackPressed();
		this.finish();
	}
	
	public void Show_Quantity_Dialog(String item) {
		final QuantityDialog qd = new QuantityDialog(MenuPage.this);
		final String item1=item;
		qd.show();
		Button ok = (Button) qd.findViewById(R.id.button1);
		Button cancel = (Button) qd.findViewById(R.id.button2);
		ok.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
            	NumberPicker n1=(NumberPicker)qd.findViewById(R.id.numberPicker1);
            	quan=n1.getValue();
            	if(quan!=0)
				Show_Date_Dialog(item1);
				qd.dismiss();
            }
        });
		cancel.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
            	qd.dismiss();
            }
        });
	}
	
	public void Show_Date_Dialog(String item) {
		final DateDialog dd = new DateDialog(MenuPage.this);
		final String item2=item;
				
		dd.show();
		Button ok = (Button) dd.findViewById(R.id.button1);
		Button cancel = (Button) dd.findViewById(R.id.button2);
		ok.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
            	DatePicker d1=(DatePicker)dd.findViewById(R.id.datePicker1);
            	int d1_month=d1.getMonth()+1;
            	int d1_day=d1.getDayOfMonth();
        		int d1_year=d1.getYear();
        		d1_date=d1_year+"-"+d1_month+"-"+d1_day;
        		
        		Calendar now = Calendar.getInstance();
        		int year = now.get(Calendar.YEAR);
        		int month = now.get(Calendar.MONTH)+1;
        		int day = now.get(Calendar.DAY_OF_MONTH);
        		d2_date=year+"-"+month+"-"+day;
        		
        		Log.e("date 1", d1_date);
        		Log.e("date 2", d2_date);
        		
        		long diff=0,days_diff=0;
        		
        		SimpleDateFormat myFormat = new SimpleDateFormat("yyyy-MM-dd");
        		try
        		{
        			java.util.Date date1 = myFormat.parse(d1_date);
        			java.util.Date date2 = myFormat.parse(d2_date);
        			diff = date1.getTime() - date2.getTime();
        			Log.e("diff", diff+"");
        			days_diff=TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
        			Log.e("days_diff", days_diff+"");
        		}
        		catch(Exception e)
        		{
        			e.printStackTrace();
        		}
        		
        		
        		if(days_diff<0)
        		{
                	Toast.makeText(getApplicationContext(), "Please Select A Valid Consume By Date.\n(higher than the current date)", Toast.LENGTH_SHORT).show();
                	return;
        		}
        		else if(days_diff>10)
        		{
        			Toast.makeText(getApplicationContext(), "Please Select A Valid Consume By Date.\n(within 10 days from now)", Toast.LENGTH_LONG).show();
                	return;
        		}
        		
        		db = new DBAdapter(MenuPage.this);
				db.open();
				if(item2.equals("Skim Milk"))
				{
					db.insertToCart(1, item2, quan, d1_date);
				}
				if(item2.equals("One Percent Milk"))
				{
					db.insertToCart(2, item2, quan, d1_date);
				}
				if(item2.equals("Two Percent Milk"))
				{
					db.insertToCart(3, item2, quan, d1_date);
				}
				if(item2.equals("Regular Milk"))
				{
					db.insertToCart(4, item2, quan, d1_date);
				}
				if(item2.equals("Chocolate Milk"))
				{
					db.insertToCart(5, item2, quan, d1_date);
				}
		        db.close();
            	Toast.makeText(getApplicationContext(), quan+" - "+item2+" added to cart to be consumed by "+d1_date+".", Toast.LENGTH_LONG).show();
            	dd.dismiss();
            }
        });
		cancel.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
            	dd.dismiss();
            }
        });
	}
	
	public void Show_Prompt_Dialog() {
		final PromptDialog pd = new PromptDialog(MenuPage.this);
		pd.show();
		Button reset = (Button) pd.findViewById(R.id.button1);
		Button cont = (Button) pd.findViewById(R.id.button2);
		reset.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
            	db.open();
		        boolean del=db.deleteAllItems();
		        if(del)
		        {
		        	Toast.makeText(getApplicationContext(), "Your cart has been cleaned.", Toast.LENGTH_LONG).show();
		        }
		        db.close();
		        pd.dismiss();
            }
        });
		cont.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
            	pd.dismiss();
            }
        });
	}
}
