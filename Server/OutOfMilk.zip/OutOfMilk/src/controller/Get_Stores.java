package controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.amazonaws.services.dynamodbv2.datamodeling.JsonMarshaller;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.ItemCollection;
import com.amazonaws.services.dynamodbv2.document.QueryOutcome;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.spec.QuerySpec;
import com.amazonaws.services.dynamodbv2.document.utils.ValueMap;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.ComparisonOperator;
import com.amazonaws.services.dynamodbv2.model.Condition;
import com.amazonaws.services.dynamodbv2.model.PutItemRequest;
import com.amazonaws.services.dynamodbv2.model.PutItemResult;
import com.amazonaws.services.dynamodbv2.model.ScanRequest;
import com.amazonaws.services.dynamodbv2.model.ScanResult;
import com.amazonaws.services.dynamodbv2.util.Tables;
import com.amazonaws.transform.JsonErrorUnmarshaller;
import com.fasterxml.jackson.databind.ObjectMapper;

import model.Store;

/**
 * Servlet implementation class Get_Stores
 */
public class Get_Stores extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static AmazonDynamoDBClient dynamoDBClient;
	static DynamoDB dynamoDB;
	
	/**
	 * @see Servlet#init(ServletConfig)
	 */
	/* Initialize connection to the DynamoDB if not done so already */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		if(dynamoDB == null){
			AWSCredentials credentials = null;
	        try {
	            credentials = new ProfileCredentialsProvider("default").getCredentials();
	        } catch (Exception e) {
	            throw new AmazonClientException(
	                    "Cannot load the credentials from the credential profiles file. " +
	                    "Please make sure that your credentials file is at the correct " +
	                    "location (/Users/Viraj/.aws/credentials), and is in valid format.",
	                    e);
	        }
	        dynamoDBClient = new AmazonDynamoDBClient(credentials);
	        Region usWest2 = Region.getRegion(Regions.US_WEST_2);
	        dynamoDBClient.setRegion(usWest2);
	        dynamoDB = new DynamoDB(dynamoDBClient);
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	/* API to return closest stores to the given location */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		// /get_stores?latitude=45.1
		
		Double userLatitude = Double.parseDouble(request.getParameter("latitude"));
		DynamoDBMapper mapper = new DynamoDBMapper(dynamoDBClient);
		ObjectMapper jmapper = new ObjectMapper();
		
		try {
            String tableName = "Stores";
            
            if(Tables.doesTableExist(dynamoDBClient, tableName)){
            	
            	Table table = dynamoDB.getTable(tableName);
            	
            	Double plus = userLatitude + 0.2d;
            	Double minus = userLatitude - 0.2d;
            	
            	DynamoDBScanExpression scanExpression = new DynamoDBScanExpression();

                Map<String, Condition> scanFilter = new HashMap<String, Condition>();
                
                /* Querying stores in approximately 50 miles radius */
                Condition scanCondition = 
                    new Condition().withComparisonOperator(ComparisonOperator.BETWEEN)
                    .withAttributeValueList(
                    		new AttributeValue().withN(minus.toString()),
                    		new AttributeValue().withN(plus.toString()));
                
                scanFilter.put("Latitude", scanCondition);
                scanExpression.setScanFilter(scanFilter);
            	
            		ArrayList<Store> scanResult = new ArrayList(mapper.scan(Store.class, scanExpression));
            		
            	    String storeListJSON = jmapper.writeValueAsString(scanResult);
            		
            		response.getWriter().append(storeListJSON);
            		
            } else {
            	response.getWriter().write(jmapper.writeValueAsString(new ArrayList<Store>()));
            }
		} catch (Exception e) {
			response.getWriter().write(jmapper.writeValueAsString(new ArrayList<Store>()));
        } 
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
