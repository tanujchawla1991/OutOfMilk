package controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.GetItemRequest;
import com.amazonaws.services.dynamodbv2.model.GetItemResult;
import com.amazonaws.services.dynamodbv2.util.Tables;
import com.fasterxml.jackson.databind.ObjectMapper;

import model.User;

/**
 * Servlet implementation class Authenticate_User
 */
public class Authenticate_User extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static DynamoDB dynamoDB;
	static AmazonDynamoDBClient dynamoDBClient;
	
	/**
	 * @see Servlet#init(ServletConfig)
	 */
	/* Initialize connection to the DynamoDB if not done so already */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		if(dynamoDB == null){
			AWSCredentials credentials = null;
	        try {
	            credentials = new ProfileCredentialsProvider("default").getCredentials();
	        } catch (Exception e) {
	            throw new AmazonClientException(
	                    "Cannot load the credentials from the credential profiles file. " +
	                    "Please make sure that your credentials file is at the correct " +
	                    "location (/Users/Viraj/.aws/credentials), and is in valid format.",
	                    e);
	        }
	        dynamoDBClient = new AmazonDynamoDBClient(credentials);
	        Region usWest2 = Region.getRegion(Regions.US_WEST_2);
	        dynamoDBClient.setRegion(usWest2);
	        dynamoDB = new DynamoDB(dynamoDBClient);
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	/* Authenticate the User. If its a valid user, send the user details */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// /authenticate_user?imei_id=123456789
		
		ObjectMapper jmapper = new ObjectMapper();
				try {
		            String tableName = "Users";
		            DynamoDBMapper mapper = new DynamoDBMapper(dynamoDBClient);
		            
		            
		            
		            if(Tables.doesTableExist(dynamoDBClient, tableName)){
		            	// Add an item
		                Map<String, AttributeValue> item = new HashMap<String,AttributeValue>();
		                item.put("UserId", new AttributeValue(request.getParameter("imei_id")));
		                GetItemRequest getItemRequest = new GetItemRequest(tableName, item);
		                GetItemResult getItemResult = dynamoDBClient.getItem(getItemRequest);
		                Map<String,AttributeValue> map = getItemResult.getItem();
		                
		                User recvdUser = new User();
		                
		                if(map != null){
		                
			                for(Map.Entry<String, AttributeValue> e : map.entrySet()){
			                	switch(e.getKey()){
				                	case "Name":
				                	{
				                		recvdUser.setName(e.getValue().getS());
				                		break;
				                	}
				                	case "Address":
				                	{
				                		recvdUser.setAddress(e.getValue().getS());
				                		break;
				                	}
				                	case "UserId":
				                	{
				                		recvdUser.setUser_id(e.getValue().getS());
				                		break;
				                	}
				                	case "Contact":
				                	{
				                		recvdUser.setContact(e.getValue().getS());
				                		break;
				                	}
				                	case "Email":
				                	{
				                		recvdUser.setEmail(e.getValue().getS());
				                		break;
				                	}
				                	case "Latitude":
				                	{
				                		recvdUser.setLatitude(Double.parseDouble(e.getValue().getN()));
				                		break;
				                	}
				                	case "Longitude":
				                	{
				                		recvdUser.setLongitude(Double.parseDouble(e.getValue().getN()));
				                		break;
				                	}
			                	}
			                }
			                
		                }
		                response.getWriter().write(jmapper.writeValueAsString(recvdUser));
		                
		            } else {
		            	response.getWriter().write("Else");
		            }
				} catch (Exception e) {
					e.printStackTrace();
					response.getWriter().write(e.getMessage());
		        } 
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
