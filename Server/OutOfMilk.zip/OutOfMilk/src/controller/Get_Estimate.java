package controller;

import java.io.IOException;
import java.lang.Iterable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.amazonaws.AmazonClientException;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapperFieldModel;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.ItemCollection;
import com.amazonaws.services.dynamodbv2.document.QueryOutcome;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.spec.GetItemSpec;
import com.amazonaws.services.dynamodbv2.document.spec.QuerySpec;
import com.amazonaws.services.dynamodbv2.document.utils.ValueMap;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.ComparisonOperator;
import com.amazonaws.services.dynamodbv2.model.Condition;
import com.amazonaws.services.dynamodbv2.model.ScanRequest;
import com.amazonaws.services.dynamodbv2.model.ScanResult;
import com.amazonaws.services.dynamodbv2.util.Tables;
import com.fasterxml.jackson.databind.ObjectMapper;

import model.Estimate;
import model.InventoryItem;
import model.Order;
import model.Store;

import org.joda.time.DateTime;
import org.joda.time.Days;

/**
 * Servlet implementation class Get_Estimate
 */
public class Get_Estimate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static AmazonDynamoDBClient dynamoDBClient;
	static DynamoDB dynamoDB;

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	/* Initialize connection to the DynamoDB if not done so already */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		if(dynamoDB == null){
			AWSCredentials credentials = null;
	        try {
	            credentials = new ProfileCredentialsProvider("default").getCredentials();
	        } catch (Exception e) {
	            throw new AmazonClientException(
	                    "Cannot load the credentials from the credential profiles file. " +
	                    "Please make sure that your credentials file is at the correct " +
	                    "location (/Users/Viraj/.aws/credentials), and is in valid format.",
	                    e);
	        }
	        dynamoDBClient = new AmazonDynamoDBClient(credentials);
	        Region usWest2 = Region.getRegion(Regions.US_WEST_2);
	        dynamoDBClient.setRegion(usWest2);
	        dynamoDB = new DynamoDB(dynamoDBClient);
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	/* API to get estimated price for the given stores & items */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// /get_estimate?order=6,5,3;2,10,2015-12-10;5,1,2015-12-06;1,20,2015-12-13
		
		ObjectMapper jmapper = new ObjectMapper();
		
		/* This Date formatter formats default java representation of time which is in Milliseconds into
		 * human readable format */
		SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
		
		// Parsing the Order String into individual orders
		String[] orderRequest = request.getParameter("order").split(";");
		
		String[] storeIds = orderRequest[0].split(",");
		ArrayList<String> itemIds = new ArrayList<String>();
		ArrayList<Order> orders = new ArrayList<>();
		
		// Hashmap containing Stores, items they sell & their respective prices
		Map<Integer,Map<Integer,Double>> storesItemsPrices = new HashMap<Integer,Map<Integer,Double>>();
		
		// Hashmap containing data required to calculate the estimate 
    	Map<Integer,Map<Integer,ArrayList<InventoryItem>>> estimateMap = 
    			new HashMap<Integer,Map<Integer,ArrayList<InventoryItem>>>();
		
		
		// Parsing request into distinct Orders
		for(int i = 1;i< orderRequest.length; i++){
			
			String[] orderParts = orderRequest[i].split(",");
			Order o = new Order();
			
			try{
				o.setItem_id(Integer.parseInt(orderParts[0]));
				itemIds.add(orderParts[0]);		// Collecting the Item Ids to query Item Prices later
				o.setQuantity(Integer.parseInt(orderParts[1]));
				o.setDate(dateFormatter.parse(orderParts[2]));
			} catch(Exception e){
				// return empty Estimate Object
			}
			
			orders.add(o);
		}
		
		
		// Populating prices for the items ordered from each store
		storesItemsPrices =  getStoresItemsPrices(storeIds,itemIds);
		
		// Querying DynamoDB for each Store with each ItemId for Inventory
		try {
			// DynamoDB table name
            String tableName = "Inventory";
            
            if(Tables.doesTableExist(dynamoDBClient, tableName)){
            	
            	Table table = dynamoDB.getTable(tableName);
            	
            	// Iterating over each Store
            	for(String storeId : storeIds){
            		int istoreId = Integer.parseInt(storeId);
            		
            		/* Hashmap containing all the items available at a particular store along with the Quantity
            		 * and the Expiration date */
            		Map<Integer,ArrayList<InventoryItem>> storeInventory = new HashMap<Integer,ArrayList<InventoryItem>>();
					
            		/* Iterating over each Item in the order */
            		for (Order o : orders) {
            			
            			/* Creating a query to fetch the quantities & expiration dates of an Item */ 
						QuerySpec spec = new QuerySpec()
							    .withKeyConditionExpression("StoreId = :store_id and begins_with(ItemIdExpiration,:item_id)")
							    .withValueMap(new ValueMap()
							        .withNumber(":store_id", istoreId)
							        .withString(":item_id", Integer.toString(o.getItem_id())))
							    .withConsistentRead(true);

							ItemCollection<QueryOutcome> items = table.query(spec);
							
							/* Putting results received from the DynamoDB in Java objects for ease of processing */
							ArrayList<InventoryItem> inventory = new ArrayList<InventoryItem>();
							for(Item i : items){
								InventoryItem inv = new InventoryItem();
								String[] ItemIdExpiration = i.getString("ItemIdExpiration").split(",");
								inv.setItem_id(Integer.parseInt(ItemIdExpiration[0]));
								inv.setDate(dateFormatter.parse(ItemIdExpiration[1]));
								inv.setQuantity(Integer.parseInt(i.getString("Quantity")));
								inventory.add(inv);
							}
							/* Sorting the Inventory in ascending order of the Expiry dates */
							Collections.sort(inventory);
							storeInventory.put(o.getItem_id(),inventory);
					}
					estimateMap.put(istoreId, storeInventory);
            	}
            	
            	ArrayList<Estimate> estimateList = new ArrayList<Estimate>();
            	
            	estimate_cost(estimateMap,storesItemsPrices, orders, estimateList);
            	
            	/* Sending a JSON response containing the estimates calculated using Dyanmic Pricing */ 
            	response.getWriter().write(jmapper.writeValueAsString(estimateList));
            	
            } else {
            	/* In case of any issue, sending an Empty list as expected by the Mobile App */
            	response.getWriter().write(jmapper.writeValueAsString(new ArrayList<Estimate>()));
            }
		} catch (Exception e) {
			/* In case of any issue, sending an Empty list as expected by the Mobile App */
			response.getWriter().write(jmapper.writeValueAsString(new ArrayList<Estimate>()));
        } 
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
	// Read all the Item prices from all available stores 
	private Map<Integer,Map<Integer,Double>> getStoresItemsPrices(String[] storeIds,ArrayList<String> itemIds){
		
		Map<Integer,Map<Integer,Double>> storesItemsPrices = new HashMap<Integer,Map<Integer,Double>>();
		
		try {
            String tableName = "Items";
            
            if(Tables.doesTableExist(dynamoDBClient, tableName)){
            	
            	Table table = dynamoDB.getTable(tableName);
            	
            	for(String storeId : storeIds){
            		int istoreId = Integer.parseInt(storeId);
            		Map<Integer,Double> mapItemPrice = new HashMap<Integer,Double>();
					for (String itemId : itemIds) {
						
						/* Generating a query to fetch prices for the ordered items at each store */
						QuerySpec spec = new QuerySpec()
							    .withKeyConditionExpression("StoreId = :store_id and ItemId = :item_id")
							    .withValueMap(new ValueMap()
							        .withNumber(":store_id", istoreId)
							        .withNumber(":item_id", Integer.parseInt(itemId)))
							    .withConsistentRead(true);

							ItemCollection<QueryOutcome> items = table.query(spec);
						
							for(Item i : items){
								mapItemPrice.put(Integer.parseInt(itemId), i.getDouble("Price"));
							}
						
					}
					storesItemsPrices.put(istoreId, mapItemPrice);
            	}
            		
            } else {
            	System.out.println("Error : Table "+ tableName +" does not exist !!"); 
            }
		} catch (Exception e) {
			/* Returning an Empty object as expected */
			return new HashMap<Integer,Map<Integer,Double>>();
        }  
		
		return storesItemsPrices;
	}

	
	public void estimate_cost(Map<Integer,Map<Integer,ArrayList<InventoryItem>>> store_inventory,Map<Integer,Map<Integer,Double>> store_items,ArrayList<Order> order,ArrayList<Estimate> estimate)
	{
		ObjectMapper jmapper = new ObjectMapper();

		/* Iterating over each store */
		for(Integer store_id:store_inventory.keySet())
		{
			double discounted_total=0;
			double original_total=0;
			boolean flag=false;
			
			/* Iterating over each Item */
			for(Order order_item:order)
			{
				double discounted_price=0;
				double original_price=0;
				int count=order_item.getQuantity();
				
				ArrayList<InventoryItem> temp = store_inventory.get(store_id).get(order_item.getItem_id());
				
				Double item_price=store_items.get(store_id).get(order_item.getItem_id());
				
				for(int i=0;i<temp.size();i++)
				{
					try
					{
						/* Expiry date of the Item*/
						DateTime expiryDate = new DateTime(temp.get(i).getDate());
						/* Expiry date acceptable to the consumer */
						DateTime requestedExpiry= new DateTime(order_item.getDate());
						
						/* Only consider the items expiring after the date customer asked for */
						if(!requestedExpiry.isAfter(expiryDate))
						{
							Calendar cal = Calendar.getInstance();
						    cal.set(Calendar.HOUR_OF_DAY, 0);
						    cal.set(Calendar.MINUTE, 0);
						    cal.set(Calendar.SECOND, 0);
						    cal.set(Calendar.MILLISECOND, 0);
							DateTime todayDate = new DateTime(cal.getTime());
							double diff=Days.daysBetween(todayDate, expiryDate).getDays();
							
							/* Logic to calculate estimate if the quantity requested spans across multiple 
							 * expiry dates
							 */
							if(temp.get(i).getQuantity()<count)
							{
								count=count-temp.get(i).getQuantity();
								original_price=original_price+(temp.get(i).getQuantity()*item_price);
								discounted_price=discounted_price+(((diff/10)+(10-diff)/20)*temp.get(i).getQuantity()*item_price);
							}
							else
							{
								original_price=original_price+(count*item_price);
								discounted_price=discounted_price+(((diff/10)+(10-diff)/20)*count*item_price);
								
								count=0;
								break;
							}
						}
					}
					catch(Exception e)
					{
						System.out.println(e.getMessage());
						e.printStackTrace();
					}
				}
				
				if(count!=0)
				{
					flag=true;
					break;
				}
				
				original_total=original_total+original_price;
				discounted_total=discounted_total+discounted_price;
				
			}
			
			if(!flag)
			{
				Estimate est=new Estimate();
				est.setStore_id(store_id);
				est.setOriginal_price(original_total);
				est.setDiscounted_price(discounted_total);
				estimate.add(est);
			}
			
		}
	}

	
}
