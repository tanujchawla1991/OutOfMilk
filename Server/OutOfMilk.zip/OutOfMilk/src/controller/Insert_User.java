package controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.PutItemRequest;
import com.amazonaws.services.dynamodbv2.model.PutItemResult;
import com.amazonaws.services.dynamodbv2.util.Tables;
import com.fasterxml.jackson.databind.ObjectMapper;

import model.User;

/**
 * Servlet implementation class Insert_User
 */
public class Insert_User extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static AmazonDynamoDBClient dynamoDB;
	
	/**
	 * @see Servlet#init(ServletConfig)
	 */
	/* Initialize connection to the DynamoDB if not done so already */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		if(dynamoDB == null){
			AWSCredentials credentials = null;
	        try {
	            credentials = new ProfileCredentialsProvider("default").getCredentials();
	        } catch (Exception e) {
	            throw new AmazonClientException(
	                    "Cannot load the credentials from the credential profiles file. " +
	                    "Please make sure that your credentials file is at the correct " +
	                    "location (/Users/Viraj/.aws/credentials), and is in valid format.",
	                    e);
	        }
	        dynamoDB = new AmazonDynamoDBClient(credentials);
	        Region usWest2 = Region.getRegion(Regions.US_WEST_2);
	        dynamoDB.setRegion(usWest2);
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	/* API to create a new user or update the existing user information */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		User newUser = new User();
		newUser.setUser_id(request.getParameter("imei_id"));
		newUser.setName(request.getParameter("name"));
		newUser.setEmail(request.getParameter("email"));
		newUser.setContact(request.getParameter("contact"));
		newUser.setAddress(request.getParameter("address"));
		newUser.setLatitude(Double.parseDouble(request.getParameter("latitude")));
		newUser.setLongitude(Double.parseDouble(request.getParameter("longitude")));
		
		
		ObjectMapper jmapper = new ObjectMapper();
		
		// /insert_user?imei_id=123456789&name=Viraj&contact=555-555-5555&address=124%20Louis%20Street,Apt%20%231,New%20Brunswick,NJ%2008901&latitude=45.034&longitude=54.543&email=viraj.lad%40gmail.com
		
		try {
            String tableName = "Users";
            
            if(Tables.doesTableExist(dynamoDB, tableName)){
            	// Add an item
                Map<String, AttributeValue> item = newItem(newUser);
                PutItemRequest putItemRequest = new PutItemRequest(tableName, item);
                PutItemResult putItemResult = dynamoDB.putItem(putItemRequest);
                response.getWriter().append(jmapper.writeValueAsString(newUser));
            } else {
            	response.getWriter().write(jmapper.writeValueAsString(new User()));
            }
		} catch (Exception e) {
			response.getWriter().write(jmapper.writeValueAsString(new User()));
        } 
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

	/* Creating a User item which can directly be passed to DynamoDB */
	private static Map<String, AttributeValue> newItem(User newUser) {
        Map<String, AttributeValue> item = new HashMap<String, AttributeValue>();
        item.put("UserId", new AttributeValue(newUser.getUser_id()));
        item.put("Name", new AttributeValue(newUser.getName()));
        item.put("Email", new AttributeValue(newUser.getEmail()));
        item.put("Contact", new AttributeValue(newUser.getContact()));
        item.put("Address", new AttributeValue(newUser.getAddress()));
        item.put("Latitude", new AttributeValue().withN(Double.toString(newUser.getLatitude())));
        item.put("Longitude", new AttributeValue().withN(Double.toString(newUser.getLongitude())));
        
        return item;
    }
}
