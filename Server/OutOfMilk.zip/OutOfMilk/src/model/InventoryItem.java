package model;

import java.util.Date;

/* Inventory objects containing Item ids, Quantity & the Expiration date.
 * Overridden compareTo() method for ease of sorting according to the expiration date */
public class InventoryItem implements Comparable<InventoryItem>{
	
	int item_id;
	int quantity;
	Date date; 
	
	
	@Override
	public int compareTo(InventoryItem o) {
		// TODO Auto-generated method stub
		return this.date.compareTo(o.getDate());
	}

	public int getItem_id() {
		return item_id;
	}

	public void setItem_id(int item_id) {
		this.item_id = item_id;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

}
