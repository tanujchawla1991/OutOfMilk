package model;

/* Estimate object for each store. 
 * Will contain the prices calculated by Dynamic Pricing */
public class Estimate {
		
	int store_id;
	double original_price;
	double discounted_price;
	   
	public int getStore_id() {
		return store_id;
	}
	public void setStore_id(int store_id) {
		this.store_id = store_id;
	}
	public double getOriginal_price() {
		return original_price;
	}
	public void setOriginal_price(double original_price) {
		this.original_price = original_price;
	}
	public double getDiscounted_price() {
		return discounted_price;
	}
	public void setDiscounted_price(double discounted_price) {
		this.discounted_price = discounted_price;
	}
	   
	   
}
