package model;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBRangeKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;

/* Class utilizing DynamoDB Mapper interface.
 * The objects can be directly mapped to the entities 
 * stored in DynamoDB tables */

@DynamoDBTable(tableName="Stores")
public class Store {
	
	   int store_id;
	   String name;
	   String address;
	   double latitude;
	   double longitude;
	   
	@DynamoDBHashKey(attributeName="StoreId")
	public int getStore_id() {
		return store_id;
	}
	public void setStore_id(int store_id) {
		this.store_id = store_id;
	}
	
	@DynamoDBAttribute(attributeName="Name")
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@DynamoDBAttribute(attributeName="Address")
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	@DynamoDBRangeKey(attributeName="Latitude")
	public double getLatitude() {
		return latitude;
	}
	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}
	
	@DynamoDBAttribute(attributeName="Longitude")
	public double getLongitude() {
		return longitude;
	}
	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}
	   
}
