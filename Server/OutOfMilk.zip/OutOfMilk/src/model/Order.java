package model;

import java.util.Date;

/* Objects containing items ordered along with their quantity & acceptable expiry date*/
public class Order {

	int item_id;
	int quantity;
	Date date;

	public int getItem_id() {
		return item_id;
	}

	public void setItem_id(int item_id) {
		this.item_id = item_id;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

}
